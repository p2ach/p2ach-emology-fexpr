
peach_compare.py : Facereader 결과와 Peach 결과의 비교
Usage:
python peach_compare.py facereder_file peach_file
Example:
python peach_compare.py drryu1_20-117_20220319_BGT_76cb68.txt test_20-117_20220319_BGT_camera1.txt 
(주의) 첫번 파일이 Facereader 파일, 두번째가 peach 파일

Peach 결과 중 오류
22-082: date 오류
Facereader 파일의 날짜와 Peach 파일의 날짜가 다름
원본은 20220419, Peach는 20220716

20-040: 카메라id 오류
20220428 디렉토리: 일부만 변환됨
20220514 디렉토리: 카메라 id 다름 (Peach 파일안에 Filename: line)
(주의) camera1, 2와 원본 카메라의 매핑을 이 라인을 읽어서 하기 때문에 extension은 .webm이더라도 파일명은 동일해야 함.
camera1:
Filename:  test_20-040_20220514_CAT_3a4d6c.webm
camera2:
Filename:  test_20-040_20220514_CAT_5a82d3.webm
원본:
drryu1_20-040_20220514_CAT_bbb0a5.txt 
drryu1_20-040_20220514_CAT_e645ce.txt




